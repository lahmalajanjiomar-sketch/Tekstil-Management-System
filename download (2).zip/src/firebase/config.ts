
export const firebaseConfig = {
  "apiKey": "AIzaSyCV3T_piyG-a11Lp5gS5Zz-a70sx2yTrp8",
  "authDomain": "khsayem-tekstil.firebaseapp.com",
  "projectId": "khsayem-tekstil",
  "storageBucket": "khsayem-tekstil.appspot.com",
  "messagingSenderId": "390185499982",
  "appId": "1:390185499982:web:65433a5953a748a0a473e3"
};
